;(function(window) {

  var svgSprite = '<svg>' +
    '' +
    '<symbol id="icon-sousuo01" viewBox="0 0 1024 1024">' +
    '' +
    '<path d="M864.370836 884.784308c-5.227267 0-10.423834-2.216481-14.064911-6.52153L644.666984 635.206066c-6.185122-7.308453-5.735872-18.137079 1.033583-24.90625 22.970095-22.980387 41.300325-49.607838 54.484132-79.145571 15.116914-33.882692 22.785892-70.032006 22.785892-107.447151 0-145.538701-118.40866-263.942391-263.95347-263.942391S195.063652 278.168394 195.063652 423.707095c0 145.536654 118.40866 263.940344 263.95347 263.940344 36.87741 0 72.541128-7.450692 106.006692-22.146393 9.322711-4.080945 20.173282 0.146333 24.259515 9.455349 4.090327 9.311063-0.144292 20.172435-9.452676 24.260543-38.158643 16.756639-78.807095 25.252127-120.813531 25.252127-165.84908 0-300.776642-134.921899-300.776642-300.761971 0-165.842119 134.927562-300.764018 300.776642-300.764018s300.776642 134.921899 300.776642 300.764018c0 42.617633-8.742472 83.817987-25.985905 122.452913-12.716137 28.497031-29.631075 54.609759-50.393806 77.830623l195.004297 230.489488c6.566831 7.762801 5.60079 19.377326-2.162337 25.948999C872.795046 883.350656 868.573731 884.784308 864.370836 884.784308z"  ></path>' +
    '' +
    '</symbol>' +
    '' +
    '<symbol id="icon-hanbaobao1" viewBox="0 0 1024 1024">' +
    '' +
    '<path d="M80.111328 528 192.962891 528C201.799446 528 208.962891 520.836555 208.962891 512 208.962891 503.163445 201.799446 496 192.962891 496L80.111328 496C71.274772 496 64.111328 503.163445 64.111328 512 64.111328 520.836555 71.274772 528 80.111328 528ZM336.427734 528 944 528C952.836555 528 960 520.836555 960 512 960 503.163445 952.836555 496 944 496L336.427734 496C327.591178 496 320.427734 503.163445 320.427734 512 320.427734 520.836555 327.591178 528 336.427734 528ZM80.055664 176 192.907227 176C201.743782 176 208.907227 168.836555 208.907227 160 208.907227 151.163444 201.743782 144 192.907227 144L80.055664 144C71.219108 144 64.055664 151.163444 64.055664 160 64.055664 168.836555 71.219108 176 80.055664 176ZM336.37207 176 943.944336 176C952.780891 176 959.944336 168.836555 959.944336 160 959.944336 151.163444 952.780891 144 943.944336 144L336.37207 144C327.535514 144 320.37207 151.163444 320.37207 160 320.37207 168.836555 327.535514 176 336.37207 176ZM80.055664 880 192.907227 880C201.743782 880 208.907227 872.836555 208.907227 864 208.907227 855.163445 201.743782 848 192.907227 848L80.055664 848C71.219108 848 64.055664 855.163445 64.055664 864 64.055664 872.836555 71.219108 880 80.055664 880ZM336.37207 880 943.944336 880C952.780891 880 959.944336 872.836555 959.944336 864 959.944336 855.163445 952.780891 848 943.944336 848L336.37207 848C327.535514 848 320.37207 855.163445 320.37207 864 320.37207 872.836555 327.535514 880 336.37207 880Z"  ></path>' +
    '' +
    '</symbol>' +
    '' +
    '</svg>'
  var script = function() {
    var scripts = document.getElementsByTagName('script')
    return scripts[scripts.length - 1]
  }()
  var shouldInjectCss = script.getAttribute("data-injectcss")

  /**
   * document ready
   */
  var ready = function(fn) {
    if (document.addEventListener) {
      if (~["complete", "loaded", "interactive"].indexOf(document.readyState)) {
        setTimeout(fn, 0)
      } else {
        var loadFn = function() {
          document.removeEventListener("DOMContentLoaded", loadFn, false)
          fn()
        }
        document.addEventListener("DOMContentLoaded", loadFn, false)
      }
    } else if (document.attachEvent) {
      IEContentLoaded(window, fn)
    }

    function IEContentLoaded(w, fn) {
      var d = w.document,
        done = false,
        // only fire once
        init = function() {
          if (!done) {
            done = true
            fn()
          }
        }
        // polling for no errors
      var polling = function() {
        try {
          // throws errors until after ondocumentready
          d.documentElement.doScroll('left')
        } catch (e) {
          setTimeout(polling, 50)
          return
        }
        // no errors, fire

        init()
      };

      polling()
        // trying to always fire before onload
      d.onreadystatechange = function() {
        if (d.readyState == 'complete') {
          d.onreadystatechange = null
          init()
        }
      }
    }
  }

  /**
   * Insert el before target
   *
   * @param {Element} el
   * @param {Element} target
   */

  var before = function(el, target) {
    target.parentNode.insertBefore(el, target)
  }

  /**
   * Prepend el to target
   *
   * @param {Element} el
   * @param {Element} target
   */

  var prepend = function(el, target) {
    if (target.firstChild) {
      before(el, target.firstChild)
    } else {
      target.appendChild(el)
    }
  }

  function appendSvg() {
    var div, svg

    div = document.createElement('div')
    div.innerHTML = svgSprite
    svgSprite = null
    svg = div.getElementsByTagName('svg')[0]
    if (svg) {
      svg.setAttribute('aria-hidden', 'true')
      svg.style.position = 'absolute'
      svg.style.width = 0
      svg.style.height = 0
      svg.style.overflow = 'hidden'
      prepend(svg, document.body)
    }
  }

  if (shouldInjectCss && !window.__iconfont__svg__cssinject__) {
    window.__iconfont__svg__cssinject__ = true
    try {
      document.write("<style>.svgfont {display: inline-block;width: 1em;height: 1em;fill: currentColor;vertical-align: -0.1em;font-size:16px;}</style>");
    } catch (e) {
      console && console.log(e)
    }
  }

  ready(appendSvg)


})(window)